#ifndef ZEROTEST_H_
#define ZEROTEST_H_

void Test_RunAllTests();

#endif
